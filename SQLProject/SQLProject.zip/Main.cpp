#include <iostream>
#include <fstream>
#include <Windows.h>
#include "Compiler.h"
#include "DataBase.h"
#include "IOFile.h"
using namespace std;

class Menu
{
private:

	vector<string> IF_lines;
	void inline displayOptions()
	{
		cout
			<< "1. Input line commands\n"
			<< "2. TODO: do something else\n"
			<< "...or type \"0\" to quit. \n";
	}
public:
	Menu() {}
	Menu(int argc, char* argv[])
	{
		this->getInputFiles(argc, argv);
	}
	void getInputFiles(int argc, char* argv[])
	{
		for (int i = 0; i < min(5, argc - 1); ++i)
		{
			ifstream fin(argv[1 + i], ios::in | ios::binary);
			string line;
			while (getline(fin, line))
			{
				if (line.find_first_not_of(" \t\n\v\f\r") != std::string::npos)
				{
					this->IF_lines.push_back(line);
				}
			}
			fin.close();
		}
	}

	void runScripts(DataBase& db)
	{
		Compiler c;

		for (string s : IF_lines)
		{
			cout << s << endl;
			vector<tokenizer::Token> tokens = c.getParser().getTokenizer().tokenize(s);
			/*for (tokenizer::Token t : tokens)
			{
				cout << t.token_type << " ";
			}*/
			cout << endl;
			parser::Node n = c.getParser().parse(tokens);
			cout << "NUME COMANDA :: " << n.name << endl;
			//cout << endl << n.toString(0) << endl;
			statement::Statement* st = c.compile(n);

			//st->print();
			st->run(db);

			cout << "Press enter for the next command.\n";
			getchar();
		}
	}
	void runLoop(DataBase& db)
	{
		Compiler c;
		string s;

		// CLEARS ISTREAM
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		//
		system("CLS");
		while (1)
		{
			std::getline(cin, s);
			if (s == "quit") break;
			vector<tokenizer::Token> tokens = c.getParser().getTokenizer().tokenize(s);
			/*
			for (tokenizer::Token t : tokens)
			{
				cout << t.token_type << " ";
			}
			*/
			parser::Node AST = c.getParser().parse(tokens);
			//cout << endl << n.toString(0) << endl;
			if (AST.name == "ERROR_TOKEN")
			{
				cout << "Unrecognized statement!\n";
			}
			else {
				statement::Statement* st = c.compile(AST);
				st->print();
				st->run(db);

			}
		}

	}
	void runMenu(DataBase& db, bool runscripts = false)
	{
		if (runscripts)
			runScripts(db);
		while (1)
		{
			system("CLS");
			displayOptions();
			int selection;
			cin >> selection;
			if (selection == 1)
			{
				runLoop(db);
			}
			else if (selection == 0)
			{
				cout << "Quit selected.\n";
				break;
			}
		}
	}

};

int main(int argc, char* argv[])
{
	DataBase db = DataBase("DataBase");
	vector<string> files;
	try {
		files = IOFile::databaseFilesFromText("DataBase");
	}
	catch (exception e) {
		IOFile::databaseDescriptionToText(db);
	}
	if (!files.empty()) {
		for (int i = 0; i < files.size(); i++) {
			try {
				Table j = IOFile::tableFromBinary(files[i]);
				db.append(j);
			}
			catch (exception e) {
				cout << e.what() << endl;
			}
		}

	}

	Menu menu(argc, argv);
	menu.runMenu(db, false);

	return 0;
}
