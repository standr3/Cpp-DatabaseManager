#include "IOFile.h"
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <algorithm>

using namespace std;

bool IOFile::databaseDescriptionToText(DataBase& db)
{
    //numele bazei de date
    //numele tabelelor
    //nr coloane 
    //nr inregistrari Stavre Marian Alin 1058E

    string filename = db.getName() + ".txt";
    remove(filename.data());    
    
    ofstream MyFile(filename);

    // Write to the file
    MyFile << db.getName()<<endl;
    for (int i = 0; i < db.getSize(); i++) {
        MyFile << db[i].getName() << " " << db[i].getSize() << " " << db[i].getNumberOfRecordings() << endl;
    }
   

    // Close the file
    MyFile.close();

    return false;
}

vector<string> IOFile::databaseFilesFromText(string filename)
{
    vector<string> r;

    ifstream file(filename + ".txt");
    string line;
    stringstream streamLine;
    string tableName;

    getline(file, line);

    while (std::getline(file, line))
    {
        streamLine = stringstream(line);
        getline(streamLine, tableName, ' ');
        r.push_back(tableName);
    }

    return r;
}

bool IOFile::tableToText(Table& t)
{
    string filename = t.getName() + ".txt";
    remove(filename.data());
    //if (remove(filename.data()) != 0)
    //    perror("Error deleting file");
    //else
    //    puts("File successfully deleted");
    try {
        // Create and open a text file
        ofstream MyFile(t.getName() + ".txt");

        // Write to the file
        MyFile << t;

        // Close the file
        MyFile.close();
    }
    catch (exception e) {
        throw e;
        return false;
    }
    return true;
}

bool IOFile::tableToCSV(Table& table)
{

    string filename = table.getName() + ".csv";
    remove(filename.data());
    //if (remove(filename.data()) != 0)
    //    perror("Error deleting file");
    //else
    //    puts("File successfully deleted");
    try {
        // Create and open a text file
        ofstream MyFile(table.getName() + ".csv");

        // Write to the file Stavre Marian Alin 1058E
        int dim = table.getNumberOfRecordings();
        vector<pair<string, int>> colNamesAndTypes = table.getColumnNamesAndTypes();
        for (int i = 0; i < table.getSize()-1; i++) {
            MyFile << colNamesAndTypes[i].first << ',';
        }
        MyFile << colNamesAndTypes[table.getSize() - 1].first << endl;

        for (int index = 0; index < dim; index++) {
            for (int i = 0; i < table.getSize() - 1; i++) {
                MyFile <<table[i][index] << ',';
            }
            MyFile << table[table.getSize() - 1][index] << endl;
        }

        // Close the file
        MyFile.close();
        return true;
    }
    catch (exception e) {
        throw e;
        return false;
    }
    return true;


   
}

Table IOFile::tableFromCSV(string filename) {
    string line;
    string value;
    vector<pair<string, int>> columns;
    stringstream streamLine;
    ifstream file(filename + ".csv");
    int noRecordings = 0;
    getline(file, line);
    noRecordings = std::count(line.begin(), line.end(), ',') + 1;

    streamLine = stringstream(line);
    while (getline(streamLine, value, ',')) {
        columns.push_back(make_pair(value, 2)); //Stavre Marian Alin 1058E
    }
    Table t = Table(filename, columns);
    Recording r;
    while (std::getline(file, line))
    {
        streamLine = stringstream(line);
        int i = 0;
        while (getline(streamLine, value, ',')) {
            r.append(columns[i].first, "2");
            i++;
        }
        t.appendRecording(r);
        r.clear();
    }
    return t;
}

bool IOFile::tableToBinary(Table& t)
{
    string filename = t.getName() + ".tab";
    vector<pair<string, int>> cols = t.getColumnNamesAndTypes();
    remove(filename.data());

    ofstream wf(t.getName()+".tab", ios::out | ios::binary);

    //write number of characters in table name Stavre Marian Alin 1058E
    int dim = t.getName().size();
    wf.write((char*)&dim, sizeof(int));

    //write table name
    wf.write( t.getName().data() , sizeof(char) * t.getName().size());

    //write number of columns
    dim = t.getSize();
    wf.write((char*)&dim, sizeof(int));

    int noChr, noRecordings = t.getNumberOfRecordings();
    //write column names
    for (int i = 0; i < dim; i++) {
        //write Stavre Marian Alin 1058E number of characters in column name
        noChr = cols[i].first.size();
        wf.write((char*)&noChr, sizeof(int));
        //write column name
        wf.write(cols[i].first.data(), sizeof(char) * noChr);
        //write column type
        noChr = cols[i].second;
        wf.write( (char*) &noChr, sizeof(int));
    }
    wf.write((char*)&noRecordings, sizeof(int)); //write number of recordings
    //write recordings
    for (int i = 0; i < t[0].getSize(); i++) {
        for (int index = 0; index < dim; index++) {
            //write no of characters
            noChr = t[index][i].size();
            wf.write((char*)&noChr, sizeof(int));
            //write value
            wf.write(t[index][i].data(), sizeof(char) * noChr);
            
        }
    }

    wf.close();
    if (!wf.good()) {
        throw exception("Eroare in timpul scrierii in fisierul binar");
        return false;
    }

    return true;
    
}

Table IOFile::tableFromBinary(string filename)
{
    Table t;
    vector<pair<string, int>> columns;
    string file = filename + ".tab";
    ifstream myFile(file, ios::in | ios::binary);
    cout << "filename " << file << endl;
    int dim = 0; //number of characters in table name
    myFile.read((char*)&dim, sizeof(int));
    cout << "//number of characters in table name " << dim << endl<<"sizeof char "<<sizeof(char)<<endl;

    char* tableName = new char[dim];
    tableName[dim] = '\0';
    myFile.read(tableName, /*sizeof(char) * */dim);  //read table name
    cout << " table name " << tableName << endl;
    string tName = tableName;
    tName[dim] = '\0';
    cout << "table name string " << tName.data() << endl;
    //delete[] tableName;

    t.setName(tableName);

    myFile.read((char*)&dim, sizeof(int)); //read number of  Stavre Marian Alin 1058E columns in table
    cout << "Number of columns " << dim << endl;
    int noChr, noRecordings;
    char* columnName;
    int dimColumnName = 0;
    int columnType = 0;
    //read column names
    for (int i = 0; i < dim; i++) {
        //read number of characters in column name
        
        myFile.read((char*)&dimColumnName, sizeof(int));
        cout << "number of characters in column name " << dimColumnName << endl;
        //allocate memory for columnName
        
        columnName = new char[dimColumnName];
        columnName[dimColumnName] = '\0';

        //read  Stavre Marian Alin 1058E column name
        
        myFile.read(columnName, sizeof(char) * dimColumnName);
        cout << "column name " << columnName << endl;
        //read column type
        myFile.read((char*)&columnType, sizeof(int));
        cout << "column type " << columnType << endl;

        columns.push_back(make_pair(string(columnName), columnType));

        //delete columnName;
    }

    t = Table(tableName, columns);
   
    columnName = new char[3];
    myFile.read((char*)&noRecordings, sizeof(int)); //read number of recordings;
    cout << "no of recordings: " << noRecordings << endl;
    //read recordings
    Recording r;
    for (int i = 0; i < noRecordings; i++) {
        for (int index = 0; index < dim; index++) {
            //read number of characters in values
            myFile.read((char*)&dimColumnName, sizeof(int));
            cout << "no char in value " << dimColumnName << endl;
            
            //Stavre Marian Alin 1058E allocate memroy for value
            //delete[] columnName;
            columnName = new char[dimColumnName];
            columnName[dimColumnName] = '\0';

            //read value
            myFile.read(columnName, sizeof(char) * dimColumnName);
            cout << "val " << columnName << endl;

            if (i == 0)
                r.append(columns[index].first, string(columnName));
            else
                r.modify(index, string(columnName));
        }
        t.appendRecording(r);
        //r.clear();
        
    }

    //Stavre Marian Alin 1058E
    cout << "inside" << endl << t << "end" << endl;
    return t;
}


